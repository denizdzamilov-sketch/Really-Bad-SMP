package ru.reallybadsmp.ranklevels;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class RankLevelsPlugin extends JavaPlugin implements Listener {

    /** Данные одного игрока. */
    static final class Data {
        String name;
        long points;
        int kills;
        int deaths;
    }

    private final Map<UUID, Data> data = new HashMap<>();
    private final Map<UUID, Map<UUID, Long>> lastKill = new HashMap<>();
    private Map<UUID, Integer> ranks = new HashMap<>();
    private File dataFile;

    private NamespacedKey keyDamage;
    private NamespacedKey keyHealth;
    private NamespacedKey keySpeed;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        keyDamage = new NamespacedKey(this, "rl_damage");
        keyHealth = new NamespacedKey(this, "rl_health");
        keySpeed = new NamespacedKey(this, "rl_speed");
        dataFile = new File(getDataFolder(), "data.yml");
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        recalcRanks();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Data d = get(p);
            applyBonuses(p, d, false);
        }
        refreshTags();
        // автосохранение каждые 5 минут
        Bukkit.getScheduler().runTaskTimer(this, this::saveData, 20L * 300, 20L * 300);
        getLogger().info("RankLevels включён.");
    }

    @Override
    public void onDisable() {
        saveData();
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Team t : new ArrayList<>(sb.getTeams())) {
            if (t.getName().startsWith("rl_")) t.unregister();
        }
    }

    // ---------- данные ----------

    private void loadData() {
        data.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        if (!y.isConfigurationSection("players")) return;
        for (String k : y.getConfigurationSection("players").getKeys(false)) {
            try {
                UUID id = UUID.fromString(k);
                Data d = new Data();
                d.name = y.getString("players." + k + ".name", "?");
                d.points = y.getLong("players." + k + ".points");
                d.kills = y.getInt("players." + k + ".kills");
                d.deaths = y.getInt("players." + k + ".deaths");
                data.put(id, d);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveData() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Data> e : data.entrySet()) {
            String k = "players." + e.getKey();
            y.set(k + ".name", e.getValue().name);
            y.set(k + ".points", e.getValue().points);
            y.set(k + ".kills", e.getValue().kills);
            y.set(k + ".deaths", e.getValue().deaths);
        }
        try {
            getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (IOException ex) {
            getLogger().warning("Не удалось сохранить data.yml: " + ex.getMessage());
        }
    }

    private Data get(Player p) {
        Data d = data.computeIfAbsent(p.getUniqueId(), id -> new Data());
        d.name = p.getName();
        return d;
    }

    // ---------- уровни и бонусы ----------

    private int level(Data d) {
        int per = Math.max(1, getConfig().getInt("points-per-level", 50));
        return 1 + (int) (d.points / per);
    }

    private int bonusLevels(Data d) {
        int max = getConfig().getInt("max-bonus-levels", 40);
        return Math.min(Math.max(0, level(d) - 1), max);
    }

    private void setModifier(Player p, Attribute attr, NamespacedKey key, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(attr);
        if (inst == null) return;
        for (AttributeModifier m : new ArrayList<>(inst.getModifiers())) {
            if (key.equals(m.getKey())) inst.removeModifier(m);
        }
        if (amount > 0) {
            inst.addModifier(new AttributeModifier(key, amount, op, EquipmentSlotGroup.ANY));
        }
    }

    private void applyBonuses(Player p, Data d, boolean heal) {
        int lv = bonusLevels(d);
        setModifier(p, Attribute.ATTACK_DAMAGE, keyDamage,
                lv * getConfig().getDouble("bonus-per-level.damage", 0.25), AttributeModifier.Operation.ADD_NUMBER);
        setModifier(p, Attribute.MAX_HEALTH, keyHealth,
                lv * getConfig().getDouble("bonus-per-level.max-health", 0.5), AttributeModifier.Operation.ADD_NUMBER);
        setModifier(p, Attribute.MOVEMENT_SPEED, keySpeed,
                lv * getConfig().getDouble("bonus-per-level.speed", 0.004), AttributeModifier.Operation.ADD_SCALAR);
        if (heal) {
            AttributeInstance hp = p.getAttribute(Attribute.MAX_HEALTH);
            if (hp != null) p.setHealth(hp.getValue());
        }
    }

    // ---------- ранги ----------

    private void recalcRanks() {
        int top = Math.max(1, getConfig().getInt("top-count", 10));
        List<Map.Entry<UUID, Data>> list = new ArrayList<>();
        for (Map.Entry<UUID, Data> e : data.entrySet()) {
            if (e.getValue().points > 0) list.add(e);
        }
        list.sort(Comparator
                .comparingLong((Map.Entry<UUID, Data> e) -> e.getValue().points).reversed()
                .thenComparing(Comparator.comparingInt((Map.Entry<UUID, Data> e) -> e.getValue().kills).reversed())
                .thenComparing(e -> String.valueOf(e.getValue().name)));
        Map<UUID, Integer> map = new HashMap<>();
        for (int i = 0; i < list.size() && i < top; i++) map.put(list.get(i).getKey(), i + 1);
        ranks = map;
    }

    private String tagFor(UUID id) {
        Integer r = ranks.get(id);
        String value = r == null ? getConfig().getString("unranked-text", "Unranked") : String.valueOf(r);
        String fmt = getConfig().getString("tag-format", "&c#%rank% &r");
        return ChatColor.translateAlternateColorCodes('&', fmt.replace("%rank%", value));
    }

    private void applyTag(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        String name = "rl_" + p.getUniqueId().toString().replace("-", "").substring(0, 13);
        Team t = sb.getTeam(name);
        if (t == null) t = sb.registerNewTeam(name);
        t.setPrefix(tagFor(p.getUniqueId()));
        if (!t.hasEntry(p.getName())) t.addEntry(p.getName());
    }

    private void removeTag(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        String name = "rl_" + p.getUniqueId().toString().replace("-", "").substring(0, 13);
        Team t = sb.getTeam(name);
        if (t != null) t.unregister();
    }

    private void refreshTags() {
        for (Player p : Bukkit.getOnlinePlayers()) applyTag(p);
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    // ---------- события ----------

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Data d = get(p);
        applyBonuses(p, d, false);
        recalcRanks();
        refreshTags();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        removeTag(e.getPlayer());
        saveData();
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> applyBonuses(p, get(p), false));
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Data vd = get(victim);
        vd.deaths++;
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;

        Data kd = get(killer);
        int cd = getConfig().getInt("same-victim-cooldown-seconds", 300);
        long now = System.currentTimeMillis();
        Map<UUID, Long> m = lastKill.computeIfAbsent(killer.getUniqueId(), k -> new HashMap<>());
        Long last = m.get(victim.getUniqueId());
        if (cd > 0 && last != null && now - last < cd * 1000L) {
            killer.sendMessage(color("&7Очки не засчитаны: этого игрока недавно убивали."));
            return;
        }
        m.put(victim.getUniqueId(), now);

        int levelBefore = level(kd);
        Integer rankBefore = ranks.get(killer.getUniqueId());
        long gain = getConfig().getInt("kill-points", 10)
                + (long) level(vd) * getConfig().getInt("victim-level-bonus", 1);
        kd.points += gain;
        kd.kills++;

        int levelAfter = level(kd);
        applyBonuses(killer, kd, levelAfter > levelBefore);
        recalcRanks();
        refreshTags();

        killer.sendMessage(color(getConfig().getString("messages.kill", "&aУбийство! +%points% очков")
                .replace("%points%", String.valueOf(gain)).replace("%level%", String.valueOf(levelAfter))));
        if (levelAfter > levelBefore) {
            killer.sendTitle(color("&6Уровень " + levelAfter), color("&7Ты стал сильнее"), 5, 40, 10);
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        }
        Integer rankAfter = ranks.get(killer.getUniqueId());
        if (rankAfter != null && rankAfter == 1 && (rankBefore == null || rankBefore != 1)) {
            Bukkit.broadcastMessage(color(getConfig().getString("messages.became-first", "%player% теперь #1!")
                    .replace("%player%", killer.getName())));
        }
        saveData();
    }

    // ---------- команды ----------

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        switch (c.getName().toLowerCase()) {
            case "stats":
                return cmdStats(s, a);
            case "top":
                return cmdTop(s);
            case "rankadmin":
                return cmdAdmin(s, a);
            default:
                return false;
        }
    }

    private boolean cmdStats(CommandSender s, String[] a) {
        Player target;
        if (a.length > 0) {
            target = Bukkit.getPlayerExact(a[0]);
            if (target == null) {
                s.sendMessage(color("&cИгрок не найден или не в сети."));
                return true;
            }
        } else if (s instanceof Player) {
            target = (Player) s;
        } else {
            s.sendMessage("Укажи игрока: /stats <игрок>");
            return true;
        }
        Data d = get(target);
        Integer r = ranks.get(target.getUniqueId());
        String rank = r == null ? getConfig().getString("unranked-text", "Unranked") : String.valueOf(r);
        int lv = bonusLevels(d);
        s.sendMessage(color("&8&m----------&r &6" + target.getName() + " &8&m----------"));
        s.sendMessage(color("&7Ранг: &c#" + rank));
        s.sendMessage(color("&7Уровень: &e" + level(d) + " &8(очки: " + d.points + ")"));
        s.sendMessage(color("&7Убийств: &a" + d.kills + " &7Смертей: &c" + d.deaths));
        s.sendMessage(color("&7Бонусы: урон &e+" + String.format("%.2f", lv * getConfig().getDouble("bonus-per-level.damage", 0.25))
                + "&7, здоровье &e+" + String.format("%.1f", lv * getConfig().getDouble("bonus-per-level.max-health", 0.5))
                + "&7, скорость &e+" + String.format("%.1f", lv * getConfig().getDouble("bonus-per-level.speed", 0.004) * 100) + "%"));
        return true;
    }

    private boolean cmdTop(CommandSender s) {
        List<Map.Entry<UUID, Integer>> list = new ArrayList<>(ranks.entrySet());
        list.sort(Map.Entry.comparingByValue());
        s.sendMessage(color("&8&m----------&r &cТоп игроков &8&m----------"));
        if (list.isEmpty()) s.sendMessage(color("&7Пока никто не получил очков."));
        for (Map.Entry<UUID, Integer> e : list) {
            Data d = data.get(e.getKey());
            s.sendMessage(color("&c#" + e.getValue() + " &f" + d.name + " &7- уровень &e" + level(d) + " &7(убийств: " + d.kills + ")"));
        }
        return true;
    }

    private boolean cmdAdmin(CommandSender s, String[] a) {
        if (!s.hasPermission("ranklevels.admin")) {
            s.sendMessage(color("&cНет прав."));
            return true;
        }
        if (a.length == 0) {
            s.sendMessage(color("&7/rankadmin reload | set <игрок> <очки> | reset <игрок>"));
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "reload":
                reloadConfig();
                recalcRanks();
                refreshTags();
                s.sendMessage(color("&aКонфиг перезагружен."));
                return true;
            case "set": {
                if (a.length < 3) {
                    s.sendMessage(color("&7/rankadmin set <игрок> <очки>"));
                    return true;
                }
                Player p = Bukkit.getPlayerExact(a[1]);
                if (p == null) {
                    s.sendMessage(color("&cИгрок не в сети."));
                    return true;
                }
                try {
                    Data d = get(p);
                    d.points = Math.max(0, Long.parseLong(a[2]));
                    applyBonuses(p, d, false);
                    recalcRanks();
                    refreshTags();
                    saveData();
                    s.sendMessage(color("&aГотово."));
                } catch (NumberFormatException ex) {
                    s.sendMessage(color("&cОчки должны быть числом."));
                }
                return true;
            }
            case "reset": {
                if (a.length < 2) {
                    s.sendMessage(color("&7/rankadmin reset <игрок>"));
                    return true;
                }
                Player p = Bukkit.getPlayerExact(a[1]);
                if (p == null) {
                    s.sendMessage(color("&cИгрок не в сети."));
                    return true;
                }
                Data d = get(p);
                d.points = 0;
                d.kills = 0;
                d.deaths = 0;
                applyBonuses(p, d, false);
                recalcRanks();
                refreshTags();
                saveData();
                s.sendMessage(color("&aСтатистика сброшена."));
                return true;
            }
            default:
                s.sendMessage(color("&7/rankadmin reload | set <игрок> <очки> | reset <игрок>"));
                return true;
        }
    }
}
